import axios from "axios"; 
import { propertyActions } from "./property-slice"; 
export const getAllProperties = () => async (dispatch, getState) => 
{ try { dispatch(propertyActions.getRequest()); 
    const { searchParams } = getState().properties; 
    const response = await 
    axios.get(`/api/v1/rent/listing`, { params: { ...searchParams }, }); 
    if (!response) throw new Error("could not fetch any properties"); 
    const { data } = response; 
    dispatch(propertyActions.getProperties(data)); } 
    catch (error) 
    { dispatch(propertyActions.getErrors(error.message)); } };