import React,{useEffect, useState} from 'react';
import FilterModal from './FilterModal';
import { useDispatch } from 'react-redux';
import { getAllProperties } from '../../Store/Property/property-action';
import { propertyActions } from '../../Store/Property/property-slice';

const Filter = () => {
    //state for controllig modal visibility
    const [isModalOpen, setIsModalOpen] = useState(false);
    //state for storing selected filters
    const [selectedFilters,setSelectedFilters] = useState({});
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(propertyActions.updateSearchParams(selectedFilters));
        dispatch(getAllProperties());},
        [selectedFilters,dispatch]);

        const handleOpenModal = () => {
        setIsModalOpen(true); //sets isModalopen to true
    };

    const handleCloseModal = () => {
        setIsModalOpen(false); //sets isModalopen to false
    };

    //function to handle changes in filter
    const handleFilterChange = (filterName,value) => {
        //update selected filters with new values
        setSelectedFilters((prevFilters)=>({
            ...prevFilters,
            [filterName]:value,
        }));
    };
    
    return (
    <>
    <span class="material-symbols-outlined filter" onClick={handleOpenModal}>
    tune
    </span>
    {isModalOpen && (<FilterModal 
    selectedFilters={selectedFilters}
    onFilterChange={handleFilterChange}
    onClose={handleCloseModal}
    />
    )}
    </>
  );
};

export default Filter;