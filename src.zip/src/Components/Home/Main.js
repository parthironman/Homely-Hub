//wE WROTE 'rafce to bring all the code below, it is a shortcut to create a functional component.
import React from 'react' //imports react library into our JS file.
import { Outlet } from 'react-router-dom'; //used to render the contents of nested routes
import Header from "./Header";
import Footer from "./Footer";

//Arrow function(replaces use of 'function' keyword),it is a feature of ES6 ↓↓
const Main = () => {
  return (
    <div>
        {/* Rendering Header,Footer & Outlet */}
        <Header/>
        <Outlet/>
        <Footer/>
    </div>
  )
}

export default Main;